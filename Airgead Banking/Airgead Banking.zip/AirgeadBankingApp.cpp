#include "AirgeadBankingApp.h"
#include <iostream>
#include <iomanip>

using namespace std;

void AirgeadBankingApp::balanceWithoutMonthlyDeposit() {

	cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
	cout << "========================================================\n";
	cout << "Year     Year End Balance     Year End Earned Interest\n";
	cout << "------------------------------------------------------\n";

	// for loop iterates over number of years to calculate interest and balance without deposits
	for (int i = 0; i < years; ++i) {
		double monthlyInterest = 0;
		//loop through each month of the year
		for (int month = 0; month < 12; ++month) {

			//calculated interest on the balance after the deposit
			monthlyInterest += (investment) * ((interest / 100) / 12);
		}
		//added the yearly earned interest to investment
		investment += monthlyInterest;

		cout << i + 1 << setw(20) << fixed << setprecision(2) << investment << setw(20) << monthlyInterest << endl;
	}

}

void AirgeadBankingApp::balanceWithMonthlyDeposit() {


	cout << "\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "=====================================================\n";
	cout << "Year     Year End Balance     Year End Earned Interest\n";
	cout << "------------------------------------------------------\n";

	// for loop iterates over number of years to calculate interest and balance with deposits
		double monthlyInterest = 0;
		//loop through each month of the year
		for (int i = 0; i < years; ++i) {
			for (int month = 0; month < 12; ++month) {
				//add monthly deposit first
				investment += deposit;
				//calculated interest on the balance after the deposit
				monthlyInterest += (investment) * ((interest / 100) / 12);
				investment += monthlyInterest;
			}
			cout << i + 1 << setw(20) << fixed << setprecision(2) << investment << setw(20) << monthlyInterest << endl;
		}
		
		

		
	}